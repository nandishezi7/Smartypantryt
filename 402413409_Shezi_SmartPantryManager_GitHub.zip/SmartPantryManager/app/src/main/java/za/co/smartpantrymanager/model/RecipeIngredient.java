package za.co.smartpantrymanager.model;
public class RecipeIngredient { public long id,recipeId; public String name,unit; public double quantity; public RecipeIngredient(long id,long recipeId,String name,double quantity,String unit){this.id=id;this.recipeId=recipeId;this.name=name;this.quantity=quantity;this.unit=unit;} }

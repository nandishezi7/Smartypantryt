package za.co.smartpantrymanager.model;
import java.util.*;
public class Recipe { public long id; public String name,method; public int minutes,servings; public List<RecipeIngredient> ingredients=new ArrayList<>(); public Recipe(long id,String name,String method,int minutes,int servings){this.id=id;this.name=name;this.method=method;this.minutes=minutes;this.servings=servings;} }

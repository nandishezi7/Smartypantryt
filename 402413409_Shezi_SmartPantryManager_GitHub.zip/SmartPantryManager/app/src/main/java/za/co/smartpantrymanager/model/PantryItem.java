package za.co.smartpantrymanager.model;
public class PantryItem { public long id; public String name; public double quantity; public String unit; public String expiryDate; public PantryItem(){} public PantryItem(long id,String name,double quantity,String unit,String expiryDate){this.id=id;this.name=name;this.quantity=quantity;this.unit=unit;this.expiryDate=expiryDate;} }

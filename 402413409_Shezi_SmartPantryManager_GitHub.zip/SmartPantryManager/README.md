# Smart Pantry Manager

Smart Pantry Manager is a Java Android application for Mobile App Development 700. It helps users track ingredients already available at home and suggests recipes only when every required ingredient is present in sufficient quantity.


## Student information
- Student number: **402413409**
- Student name: **Nandi Shezi**
- Programme: **Bachelor of Science in Information Technology (BSc IT)**
- Year: **3**
- Module: **Mobile App Development 700**

## Core features
- Pantry Create, Read, Update and Delete (CRUD)
- Optional expiry date
- RecyclerView with custom Adapter
- 20 pre-seeded recipes stored in SQLite
- Strict recipe matching: missing ingredients or insufficient quantities exclude a recipe
- Basic ingredient normalisation for singular/plural names
- Unit compatibility for common metric/kitchen units
- Recipe detail screen
- Settings screen with persisted preferences
- Intent-based navigation between Activities
- No Google Maps, GPS or location services

## Database choice
SQLite via `SQLiteOpenHelper` was selected because the application is primarily local, does not require account-based cloud synchronisation, and the database lifecycle and CRUD operations are straightforward to demonstrate in an Android development assessment.

## Project structure
```text
app/src/main/java/za/co/smartpantrymanager/
├── data/DatabaseHelper.java
├── model/PantryItem.java
├── model/Recipe.java
├── model/RecipeIngredient.java
├── ui/MainActivity.java
├── ui/AddEditIngredientActivity.java
├── ui/SuggestedRecipesActivity.java
├── ui/RecipeDetailActivity.java
├── ui/SettingsActivity.java
├── ui/PantryAdapter.java
├── ui/RecipeAdapter.java
└── util/IngredientUtils.java
```

## Database tables
- `pantry`: user-owned pantry records
- `recipes`: seeded recipe records
- `recipe_ingredients`: required ingredients for each recipe

## Run instructions
1. Open the project folder in Android Studio.
2. Allow Android Studio to sync Gradle dependencies.
3. Use an Android emulator or Android device running API 24 or later.
4. Run the `app` configuration.
5. On first launch, the SQLite database is created and 20 recipes are seeded automatically.

## Strict matching test
To demonstrate the key business rule:
1. Add all ingredients needed by one recipe except one.
2. Open Suggested Recipes and confirm the recipe is absent.
3. Add the missing ingredient with enough quantity.
4. Return to Suggested Recipes and confirm the recipe appears.
5. Edit the ingredient so the quantity becomes insufficient and confirm the recipe disappears again.

## GitHub
Create a public GitHub repository named `SmartPantryManager` and push this project. Replace the placeholder repository link in the final report with the actual repository URL.

## Assessment evidence
The final submission should include the actual screenshots from the running application, the narrated 5–7 minute demonstration video, the report, and this source project. Do not use generated mockups as evidence of the running app.
